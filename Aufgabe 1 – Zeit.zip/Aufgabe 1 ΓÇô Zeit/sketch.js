var now = clock();
var s = now.sec;
var m = now.min;
var h = now.hours;


var centX, centY;
var counter = 0;
var aktuelleminute;
var aktuellestunde;

var stdgr = 41.6; //Quadratgröße
var diam = 32;//Radius Sekunden
var diamin = 32;//Radius Minuten


function setup() {
  createCanvas(1000, 1000);
  frameRate(1); //Schnelligkeit der Animation
  background(255);
  centX = width/2
  centY = height/2;
  strokeWeight(0);
  stroke(0);
  fill(255,30, 200,20); //neon pink
  minutenkreise(m);

  for(let i=0;i<s; i++){ //kreise von bereits verstrichenen sekunden generieren
    fill(255,30, 200,20); //35neon pink
    strokeWeight(0);
    ellipse(0, 0, diam, diam);
    diam += 32;
  }
}

function stundenquadrate(aktuellestunde){
  stdgr = 41.6;
  for(let i=0;i<aktuellestunde; i++){ //kreise von bereits verstrichenen stunden generieren
    stroke(255,255,50); // gelb
    noFill();
    strokeWeight(0.5);
    square(centX-stdgr/2,centY-stdgr/2,stdgr);
    stdgr += 41.6;

  }
}
function minutenkreise(aktuelleminute){
  diamin = 32;
  for(let j=0;j<aktuelleminute; j++){ //kreise von bereits verstrichenen minuten generieren
    fill(117, 127, 255, 35); //violett
    strokeWeight(0);
    ellipse(1000, 1000, diamin, diamin);
    diamin += 32;
  }
}



function draw() {
  var now = clock()
  var s = now.sec
  var m = now.min
  var h = now.hours
  var ms = now.m
  console.log("\nmin: "+m+"\nsek: "+s);
  
  
  if(diam < 2000-32) { //sekundenkreise generieren
    strokeWeight(0);
    fill(255,30, 200,20);//pink (letzter Wert: Deckkraft 0 bis 255)
    ellipse(0, 0, diam, diam);
    diam += 32; 

  }

  if (diam>2000-32){//if: kreis hat maximale größe erreicht(60sek) = Weißer Hintergrund
    fill(255,255, 255);//weiß
    strokeWeight(0);
    background(255);
    minutenkreise(m);
    diam = 0;  
  }

  stundenquadrate(h);

}